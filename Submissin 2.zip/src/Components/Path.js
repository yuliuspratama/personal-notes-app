const Path = {
    Root : "/" ,
    Add : "/note/add" ,
    Archive : "/note/archive",
    All : "/note/all",
    Search: "/note/search",
    Note :"/notes/:id",
    Notfound :"*",
    Register :"/Register",
    Login : "/Login",
}

export default Path