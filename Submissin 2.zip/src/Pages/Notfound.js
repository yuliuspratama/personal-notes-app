import React from 'react';

class Notfound extends React.Component{

  render(){
    return(
      <section className='notes-list-empty'>
        <h1 className='notes-list-empty p'>404 Not found</h1>
        </section>
    )
  }
}
export default Notfound;
